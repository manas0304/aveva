import time
from azure.cosmos import CosmosClient, exceptions, PartitionKey, ContainerProxy
import json

url = "Read-write-Keys_URI"
key = "Read-write-Keys_PRIMARY_KEY"
client = CosmosClient(url, credential=key)


def create_database(database_name):
    try:
        database = client.create_database(database_name)
        print(f"Database {database_name} created successfully")
        return database
    except exceptions.CosmosResourceExistsError:
        print(f"Database {database_name} exists")
        database = client.get_database_client(database_name)
        return database


def list_databases(client):
    print("\n List all Databases on an account")
    print('Databases:')
    databases = list(client.list_databases())
    for database in databases:
        print(database['id'])


def create_container(database_name: str, container_name: str, partition_key: str):
    """Create Container with the given properties.
    :param database_name: The database name in which container is created
    :param container_name: The name of the container to be created
    :param partition_key: The partition key to be used
    :return:
    """
    database = create_database(database_name)
    try:
        params = {}
        params["id"] = container_name
        params["partition_key"] = PartitionKey(path=partition_key)
        container = database.create_container(**params)
        print(f"Container {container_name} in {database_name} is created")
    except exceptions.CosmosResourceExistsError:
        print(f"Container {container_name} in {database_name} exists already")
        raise
    except exceptions.CosmosHttpResponseError:
        raise


def list_Containers(database_name):
    print("\n List all Container on an Database")
    print('Container:')
    database = client.get_database_client(database_name)
    for container in database.list_containers():
        print(container['id'])


def get_container(database_name, container_name):
    database = create_database(database_name)
    return database.get_container_client(container_name)


def insert_item(container: ContainerProxy):
    container.create_item({
        'id': '1',  # id is mandatory and it should be unique
        'productType': '4-wheeler',
        'productName': 'Kia',
        'productModel': 'Sonet',
        'Qty.': '7',
        'productId': '4w_1'
    })
    print("Insertion of item completed")


def read_items(container: ContainerProxy):
    print('\nReading all items in a container\n')
    item_list = list(container.read_all_items())
    print('Found {0} items'.format(item_list.__len__()))
    print(item_list)


def insert_multiple_items(container: ContainerProxy):
    with open('data.jsonl', 'r') as json_file:
        json_list = list(json_file)
    for json_str in json_list:
        container.create_item(json.loads(json_str))
    print("Inserted multiple items read from the data.jsonl file")


def query_items_with_condition(container):
    print('\n Querying Items with condition\n')
    # Must be set to true for any query that requires to be executed across more than one partition.
    # enable_cross_partition_query should be set to True as the container is partitioned.
    items = list(container.query_items(
        query="SELECT * FROM r where r.productType=@productType",
        parameters=[
            {"name": "@productType", "value": "4-wheeler"},
        ],
        enable_cross_partition_query=True
    ))
    print(items)
    print('Item queried resulted {}'.format(len(items)))


def update_single_item(container: ContainerProxy):
    print('\n Upserting an item\n')
    read_item = container.read_item(item="13", partition_key="4-wheeler")
    print("Item before update: ", read_item)
    read_item["Qty."] = "9"
    print("Item after update: ", read_item)
    response = container.upsert_item(body=read_item)
    print("The item is upserted")


def update_multiple_items(container: ContainerProxy):
    print('\n Upserting an item\n')
    read_items = list(container.read_all_items(partition_key="EV"))
    for item in read_items:
        item["Qty."] = "0"
        print("Item after update: ", item)
        container.upsert_item(item)
    print("Multiple items are updated")


def delete_item(container: ContainerProxy, id: str, partitionKey: str):
    container.delete_item(item=id, partition_key=partitionKey)
    print("Item with id {} deleted successfully".format(id))


def delete_multiple_items(container: ContainerProxy, ids: list, partition_key: str):
    for _id in ids:
        delete_item(container, _id, partition_key)


def main():
    create_database("CosmosDB_Name")
    # list_databases(client)
    # create_container("CosmosDB_Name", "Container_Name", "Partition_Key")
    # list_Containers("CosmosDB_Name")
    # container = get_container("CosmosDB_Name", "Container_Name")
    # insert_item(container)
    # read_items(container)
    # insert_multiple_items(container)
    # query_items_with_condition(container)
    # update_single_item(container)
    # update_multiple_items(container)
    # delete_item(container,"Id_Number", "Partition_Key")
    # delete_multiple_items(container, ["Id_Number-1", "Id_Number-2"],"Partition_Key")


if __name__ == '__main__':
    main()
