import time
from azure.cosmos import CosmosClient, exceptions, PartitionKey, ContainerProxy
import json

url = "Read-write-Keys_URI"
key = "Read-write-Keys_PRIMARY_KEY"
client = CosmosClient(url, credential=key)


def create_database(database_name):
    try:
        database = client.create_database(database_name)
        print(f"Database {database_name} created successfully")
        return database
    except exceptions.CosmosResourceExistsError:
        print(f"Database {database_name} exists")
        database = client.get_database_client(database_name)
        return database


def create_container(database_name: str, container_name: str, partition_key: str, unique_keys: list = None,
                     default_ttl: int = None):
    """Create Container with the given properties.
    :param database_name: The database name in which container is created
    :param container_name: The name of the container to be created
    :param partition_key: The partition key to be used
    :param unique_keys: The list of unique
    :param default_ttl: Default time to live (TTL) for items in the container. If unspecified, items do not expire.
    :return:
    """
    database = create_database(database_name)
    try:
        params = {}
        params["id"] = container_name
        params["partition_key"] = PartitionKey(path=partition_key)
        if unique_keys:
            params["unique_key_policy"] = {'uniqueKeys': [{'paths': unique_keys}]}
        if default_ttl:
            params["default_ttl"] = default_ttl
        container = database.create_container(**params)
        print(f"Container {container_name} in {database_name} is created")
    except exceptions.CosmosResourceExistsError:
        print(f"Container {container_name} in {database_name} exists already")
        raise
    except exceptions.CosmosHttpResponseError:
        raise


def insert_item(container: ContainerProxy):
    container.create_item({
        'id': '1',  # id is mandatory and it should be unique
        'productType': '2-wheeler',
        'productName': 'Bajaj',
        'productModel': 'Pulser',
        'CC': '150',
        'Qty.': '12',
        'productId': '2w_1'
    })
    print("Insertion of item completed")


def get_container(database_name, container_name):
    database = create_database(database_name)
    return database.get_container_client(container_name)


def read_items(container: ContainerProxy):
    print('\nReading all items in a container\n')
    item_list = list(container.read_all_items())
    print('Found {0} items'.format(item_list.__len__()))
    print(item_list)


def main():
    create_container("CosmosDB_Name", "Container_Name", "Partition_Key", ["Attribute-1", "Attribute-2", "Attribute-3"])
    # create_container("CosmosDB_Name", "Container_Name", "Partition_Key", ["Attribute-1", "Attribute-2", "Attribute-3"], TTL)
    # container = get_container("CosmosDB_Name", "Container_Name")
    # insert_item(container)
    # read_items(container)


if __name__ == '__main__':
    main()
