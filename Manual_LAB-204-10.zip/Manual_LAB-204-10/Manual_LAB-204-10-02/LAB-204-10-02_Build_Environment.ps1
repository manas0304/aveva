<#	
	Version:        1.0
	Author:         Ahmad Majeed Zahoory
	Creation Date:  4th August, 2022
	Purpose/Change: Build Environment

#>

############################################### Variables ############################################################
# Variables for common values
$resourceGroup = "az-204-10-02-rg"
$location= "eastus"
Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"

############################################### Crdentials ###########################################################
$username = "master"
$password = "Lab@password"
$secstr = New-Object -TypeName System.Security.SecureString
$password.ToCharArray() | ForEach-Object {$secstr.AppendChar($_)}
$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $username, $secstr

############################################## Resource Group ########################################################

# Create a resource group
New-AzresourceGroup -Name $resourceGroup -location $location

############################################### Virtual Network ######################################################
# Create a virtual network with subnet
$subnet1 = New-AzVirtualNetworkSubnetConfig -Name WebSubnet -AddressPrefix 192.168.0.0/24
$subnet2 = New-AzVirtualNetworkSubnetConfig -Name AppSubnet -AddressPrefix 192.168.1.0/24
$vnet = New-AzVirtualNetwork -resourceGroupName $resourceGroup -Name Image-VNeT -AddressPrefix 192.168.0.0/23 `
  -location $location -Subnet $subnet1, $subnet2

################################################  Web Server ##########################################################

# Create a public IP address and specify a DNS name
$pip1 = New-AzPublicIpAddress -resourceGroupName $resourceGroup -location $location -Name "websrvdns$(Get-Random)" -AllocationMethod Dynamic -IdleTimeoutInMinutes 4

# Create an inbound network security group rule for port 22, 80 
$nsgrule1 = New-AzNetworkSecurityRuleConfig -Name WebSrvNSGRule  -Protocol Tcp `
  -Direction Inbound -Priority 1000 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * `
  -DestinationPortRange "22", "80" -Access Allow

# Create a network security group
$nsg1 = New-AzNetworkSecurityGroup -resourceGroupName $resourceGroup -location $location `
  -Name webnsg -SecurityRules $nsgrule1
  
# Create a nic for vm
$nicvm1 = New-AzNetworkInterface -resourceGroupName $resourceGroup -location $location -Name 'websrvnic' -SubnetId $vnet.Subnets[0].Id -PublicIpAddressId $pip1.Id -NetworkSecurityGroupId $nsg1.Id

# Create a virtual machine configuration
$vmConfig1 = New-AzVMConfig -VMName web-server -VMSize Standard_D2as_v5 | `
Set-AzVMOperatingSystem -Linux -ComputerName web-server -Credential $cred | `
Set-AzVMSourceImage -PublisherName Canonical -Offer UbuntuServer -Skus 18.04-LTS -Version latest | `
Add-AzVMNetworkInterface -Id $nicvm1.Id

# Create a virtual machine
New-AzVM -resourceGroupName $resourceGroup -location $location -VM $vmConfig1

################################################  App Server ##########################################################

# Create a public IP address and specify a DNS name
$pip2 = New-AzPublicIpAddress -resourceGroupName $resourceGroup -location $location -Name "appsrvdns$(Get-Random)" -AllocationMethod Dynamic -IdleTimeoutInMinutes 4

# Create an inbound network security group rule for port 22, 80 
$nsgrule2 = New-AzNetworkSecurityRuleConfig -Name AppSrvNSGRule  -Protocol Tcp `
  -Direction Inbound -Priority 1000 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * `
  -DestinationPortRange "22", "80" -Access Allow

# Create a network security group
$nsg2 = New-AzNetworkSecurityGroup -resourceGroupName $resourceGroup -location $location `
  -Name appnsg -SecurityRules $nsgrule2
  
# Create a nic for vm
$nicvm2 = New-AzNetworkInterface -resourceGroupName $resourceGroup -location $location -Name 'appsrvnic' -SubnetId $vnet.Subnets[1].Id -PublicIpAddressId $pip2.Id -NetworkSecurityGroupId $nsg2.Id

# Create a virtual machine configuration
$vmConfig2 = New-AzVMConfig -VMName app-server -VMSize Standard_D2as_v5 | `
Set-AzVMOperatingSystem -Linux -ComputerName app-server -Credential $cred | `
Set-AzVMSourceImage -PublisherName Canonical -Offer UbuntuServer -Skus 18.04-LTS -Version latest | `
Add-AzVMNetworkInterface -Id $nicvm2.Id

# Create a virtual machine
New-AzVM -resourceGroupName $resourceGroup -location $location -VM $vmConfig2

# End